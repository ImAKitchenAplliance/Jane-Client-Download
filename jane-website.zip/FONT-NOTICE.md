# Minecraft font artwork

`public/fonts/minecraft.ttf` contains unhinted outlines converted from Minecraft Java 1.21.1's bitmap font glyphs. The glyph artwork belongs to Mojang Studios and is **not covered by this repository's MIT license**. Jane Client is not affiliated with Mojang or Microsoft. No claim of ownership or an open-source license is made for that artwork.

The source textures and provider character maps are preserved in `build/font-source/`. Retrieved from the Minecraft asset mirror at https://github.com/InventivetalentDev/minecraft-assets/tree/1.21.1/assets/minecraft (textures/font/ascii.png, textures/font/nonlatin_european.png, font/include/default.json). The conversion code in `scripts/make-minecraft-font.py` is first-party MIT code. No remote font request is made when the launcher runs. Review Minecraft's usage guidelines before redistributing Mojang assets separately from this launcher.
